#ifdef __s390x__
#include "s390/syscalls64.h"
#else
#include "s390/syscalls31.h"
#endif
