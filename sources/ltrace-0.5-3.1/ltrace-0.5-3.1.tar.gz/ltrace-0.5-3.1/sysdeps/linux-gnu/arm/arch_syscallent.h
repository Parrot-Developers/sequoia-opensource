	"0",                               /* 0 */
	"breakpoint",                      /* 1 */
	"cacheflush",                      /* 2 */
	"usr26",                           /* 3 */
	"usr32",                           /* 4 */
	"set_tls",                         /* 5 */
